CREATE TABLE `headsets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patrimonio` varchar(64) NOT NULL,
	`serie` varchar(128) NOT NULL,
	`marca` varchar(128) NOT NULL,
	`estado` enum('em_uso','manutencao','estoque','funcional') NOT NULL DEFAULT 'estoque',
	`observacoes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `headsets_id` PRIMARY KEY(`id`),
	CONSTRAINT `headsets_patrimonio_unique` UNIQUE(`patrimonio`)
);
--> statement-breakpoint
CREATE TABLE `operadores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nome` varchar(128) NOT NULL,
	`matricula` varchar(64) NOT NULL,
	`setor` varchar(128),
	`telefone` varchar(32),
	`ativo` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `operadores_id` PRIMARY KEY(`id`),
	CONSTRAINT `operadores_matricula_unique` UNIQUE(`matricula`)
);
--> statement-breakpoint
CREATE TABLE `vinculos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`headsetId` int NOT NULL,
	`operadorId` int NOT NULL,
	`dataVinculo` timestamp NOT NULL DEFAULT (now()),
	`dataDesvinculo` timestamp,
	`motivoBaixa` text,
	`ativo` boolean NOT NULL DEFAULT true,
	`criadoPor` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `vinculos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` DROP INDEX `users_openId_unique`;--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `name` text NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `username` varchar(64) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_username_unique` UNIQUE(`username`);--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `openId`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `email`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `loginMethod`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `lastSignedIn`;