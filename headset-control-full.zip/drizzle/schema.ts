import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
} from "drizzle-orm/mysql-core";

// ─── Usuários do Sistema ───────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  name: text("name").notNull(),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Headsets ─────────────────────────────────────────────────────────────────
export const headsets = mysqlTable("headsets", {
  id: int("id").autoincrement().primaryKey(),
  patrimonio: varchar("patrimonio", { length: 64 }).notNull().unique(),
  serie: varchar("serie", { length: 128 }).notNull(),
  marca: varchar("marca", { length: 128 }).notNull(),
  estado: mysqlEnum("estado", ["em_uso", "manutencao", "estoque", "funcional"])
    .default("estoque")
    .notNull(),
  observacoes: text("observacoes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Headset = typeof headsets.$inferSelect;
export type InsertHeadset = typeof headsets.$inferInsert;

// ─── Operadores ───────────────────────────────────────────────────────────────
export const operadores = mysqlTable("operadores", {
  id: int("id").autoincrement().primaryKey(),
  nome: varchar("nome", { length: 128 }).notNull(),
  matricula: varchar("matricula", { length: 64 }).notNull().unique(),
  setor: varchar("setor", { length: 128 }),
  telefone: varchar("telefone", { length: 32 }),
  ativo: boolean("ativo").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Operador = typeof operadores.$inferSelect;
export type InsertOperador = typeof operadores.$inferInsert;

// ─── Vínculos Headset ↔ Operador ──────────────────────────────────────────────
export const vinculos = mysqlTable("vinculos", {
  id: int("id").autoincrement().primaryKey(),
  headsetId: int("headsetId").notNull(),
  operadorId: int("operadorId").notNull(),
  dataVinculo: timestamp("dataVinculo").defaultNow().notNull(),
  dataDesvinculo: timestamp("dataDesvinculo"),
  motivoBaixa: text("motivoBaixa"),
  ativo: boolean("ativo").default(true).notNull(),
  criadoPor: int("criadoPor"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Vinculo = typeof vinculos.$inferSelect;
export type InsertVinculo = typeof vinculos.$inferInsert;
