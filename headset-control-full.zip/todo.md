# Sistema de Controle de Headsets - TODO

## Schema & Banco de Dados
- [x] Tabela de headsets (patrimônio, série, marca, estado)
- [x] Tabela de operadores (nome, matrícula, setor, status)
- [x] Tabela de vínculos headset-operador (com histórico)
- [x] Tabela de usuários do sistema (admin/user)
- [x] Migração do banco de dados

## Autenticação
- [x] Login com usuário/senha local (sem OAuth)
- [x] Usuário admin padrão (Admin / Pelotassss-1)
- [x] Logout
- [x] Proteção de rotas autenticadas
- [x] Gestão de sessão com JWT

## Backend (tRPC Routers)
- [x] Router de auth (login, logout, me)
- [x] Router de headsets (CRUD completo)
- [x] Router de operadores (CRUD completo)
- [x] Router de vínculos (vincular, desvincular, histórico)
- [x] Router de usuários (listar, criar, remover - admin only)
- [x] Router de dashboard (estatísticas gerais)

## Frontend - Páginas
- [x] Página de Login (design mesh gradient)
- [x] Dashboard com visão geral e estatísticas
- [x] Página de Headsets (listagem + cadastro + editar + excluir)
- [x] Página de Operadores (listagem + cadastro + editar + excluir)
- [x] Página de Vínculos (vincular headset a operador, baixa)
- [x] Página de Usuários do Sistema (admin only)

## Design & UX
- [x] Gradiente mesh vibrante (rosa, violeta, laranja, azul)
- [x] Tipografia bold branca com sombra
- [x] Layout dashboard com sidebar
- [x] Componentes de cards para estatísticas
- [x] Tabelas responsivas com ações
- [x] Toasts de feedback para operações
- [x] Estados de loading e empty states

## Testes
- [x] Testes de autenticação (login/logout)
- [x] Testes de CRUD de headsets
- [x] Testes de vínculos e dashboard
