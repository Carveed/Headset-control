import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { ENV } from "./_core/env";
import * as db from "./db";

const JWT_SECRET = new TextEncoder().encode(ENV.cookieSecret || "headset-control-secret-key");
const SALT_ROUNDS = 10;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function generateToken(userId: number, role: string): Promise<string> {
  return new SignJWT({ userId, role })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("24h")
    .setIssuedAt()
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as { userId: number; role: string };
  } catch {
    return null;
  }
}

export async function ensureAdminExists() {
  const allUsers = await db.getAllUsers();
  const adminExists = allUsers.some((u) => u.username === "Admin");
  if (!adminExists) {
    const passwordHash = await hashPassword("Pelotassss-1");
    await db.createUser({
      username: "Admin",
      passwordHash,
      name: "Administrador",
      role: "admin",
    });
    console.log("[Auth] Admin user created successfully");
  }
}
