import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Mock do módulo db
vi.mock("./db", () => ({
  getUserByUsername: vi.fn(),
  getUserById: vi.fn(),
  getAllUsers: vi.fn().mockResolvedValue([]),
  createUser: vi.fn(),
  deleteUser: vi.fn(),
  getAllHeadsets: vi.fn().mockResolvedValue([]),
  getHeadsetById: vi.fn(),
  createHeadset: vi.fn(),
  updateHeadset: vi.fn(),
  deleteHeadset: vi.fn(),
  getAllOperadores: vi.fn().mockResolvedValue([]),
  getOperadorById: vi.fn(),
  createOperador: vi.fn(),
  updateOperador: vi.fn(),
  deleteOperador: vi.fn(),
  getVinculosAtivos: vi.fn().mockResolvedValue([]),
  getVinculoByHeadsetId: vi.fn(),
  getVinculosByOperadorId: vi.fn().mockResolvedValue([]),
  createVinculo: vi.fn(),
  desativarVinculo: vi.fn(),
  getHistoricoVinculos: vi.fn().mockResolvedValue([]),
  getUserByOpenId: vi.fn().mockResolvedValue(undefined),
  upsertUser: vi.fn(),
}));

// Mock do módulo auth
vi.mock("./auth", () => ({
  hashPassword: vi.fn().mockResolvedValue("hashed_password"),
  verifyPassword: vi.fn().mockResolvedValue(true),
  generateToken: vi.fn().mockResolvedValue("mock_token"),
  verifyToken: vi.fn().mockResolvedValue({ userId: 1, role: "admin" }),
  ensureAdminExists: vi.fn().mockResolvedValue(undefined),
}));

const adminUser: User = {
  id: 1,
  username: "Admin",
  passwordHash: "hashed",
  name: "Administrador",
  role: "admin",
  createdAt: new Date(),
  updatedAt: new Date(),
};

const regularUser: User = {
  id: 2,
  username: "user1",
  passwordHash: "hashed",
  name: "Usuário Comum",
  role: "user",
  createdAt: new Date(),
  updatedAt: new Date(),
};

function createCtx(user: User | null = null): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      cookie: vi.fn(),
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("auth.me", () => {
  it("retorna null quando não autenticado", async () => {
    const caller = appRouter.createCaller(createCtx(null));
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("retorna dados do usuário quando autenticado", async () => {
    const caller = appRouter.createCaller(createCtx(adminUser));
    const result = await caller.auth.me();
    expect(result).toBeTruthy();
    expect(result?.username).toBe("Admin");
    expect(result?.role).toBe("admin");
  });

  it("não expõe o passwordHash", async () => {
    const caller = appRouter.createCaller(createCtx(adminUser));
    const result = await caller.auth.me();
    expect(result).not.toHaveProperty("passwordHash");
  });
});

describe("auth.logout", () => {
  it("limpa o cookie e retorna sucesso", async () => {
    const ctx = createCtx(adminUser);
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(ctx.res.clearCookie).toHaveBeenCalledWith("auth_token", { path: "/" });
  });
});

describe("headsets.list", () => {
  it("requer autenticação", async () => {
    const caller = appRouter.createCaller(createCtx(null));
    await expect(caller.headsets.list()).rejects.toThrow();
  });

  it("retorna lista de headsets para usuário autenticado", async () => {
    const db = await import("./db");
    vi.mocked(db.getAllHeadsets).mockResolvedValueOnce([
      {
        id: 1,
        patrimonio: "PAT-001",
        serie: "SN123",
        marca: "Jabra",
        estado: "estoque",
        observacoes: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
    const caller = appRouter.createCaller(createCtx(regularUser));
    const result = await caller.headsets.list();
    expect(result).toHaveLength(1);
    expect(result[0].patrimonio).toBe("PAT-001");
  });
});

describe("headsets.delete", () => {
  it("requer perfil admin", async () => {
    const caller = appRouter.createCaller(createCtx(regularUser));
    await expect(caller.headsets.delete({ id: 1 })).rejects.toThrow();
  });

  it("admin pode excluir headset", async () => {
    const db = await import("./db");
    vi.mocked(db.deleteHeadset).mockResolvedValueOnce(undefined);
    const caller = appRouter.createCaller(createCtx(adminUser));
    const result = await caller.headsets.delete({ id: 1 });
    expect(result.success).toBe(true);
  });
});

describe("operadores.list", () => {
  it("requer autenticação", async () => {
    const caller = appRouter.createCaller(createCtx(null));
    await expect(caller.operadores.list()).rejects.toThrow();
  });

  it("retorna lista de operadores", async () => {
    const db = await import("./db");
    vi.mocked(db.getAllOperadores).mockResolvedValueOnce([
      {
        id: 1,
        nome: "João Silva",
        matricula: "MAT-001",
        setor: "Atendimento",
        telefone: null,
        ativo: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
    const caller = appRouter.createCaller(createCtx(regularUser));
    const result = await caller.operadores.list();
    expect(result).toHaveLength(1);
    expect(result[0].nome).toBe("João Silva");
  });
});

describe("dashboard.stats", () => {
  it("requer autenticação", async () => {
    const caller = appRouter.createCaller(createCtx(null));
    await expect(caller.dashboard.stats()).rejects.toThrow();
  });

  it("retorna estatísticas corretas", async () => {
    const db = await import("./db");
    vi.mocked(db.getAllHeadsets).mockResolvedValueOnce([
      { id: 1, patrimonio: "P1", serie: "S1", marca: "M1", estado: "em_uso", observacoes: null, createdAt: new Date(), updatedAt: new Date() },
      { id: 2, patrimonio: "P2", serie: "S2", marca: "M2", estado: "estoque", observacoes: null, createdAt: new Date(), updatedAt: new Date() },
      { id: 3, patrimonio: "P3", serie: "S3", marca: "M3", estado: "funcional", observacoes: null, createdAt: new Date(), updatedAt: new Date() },
    ]);
    vi.mocked(db.getAllOperadores).mockResolvedValueOnce([
      { id: 1, nome: "Op1", matricula: "M1", setor: null, telefone: null, ativo: true, createdAt: new Date(), updatedAt: new Date() },
      { id: 2, nome: "Op2", matricula: "M2", setor: null, telefone: null, ativo: false, createdAt: new Date(), updatedAt: new Date() },
    ]);
    vi.mocked(db.getVinculosAtivos).mockResolvedValueOnce([
      { id: 1, headsetId: 1, operadorId: 1, dataVinculo: new Date(), dataDesvinculo: null, motivoBaixa: null, ativo: true, criadoPor: 1, createdAt: new Date() },
    ]);

    const caller = appRouter.createCaller(createCtx(regularUser));
    const stats = await caller.dashboard.stats();

    expect(stats.totalHeadsets).toBe(3);
    expect(stats.totalOperadores).toBe(2);
    expect(stats.operadoresAtivos).toBe(1);
    expect(stats.headsetsVinculados).toBe(1);
    expect(stats.porEstado.em_uso).toBe(1);
    expect(stats.porEstado.estoque).toBe(1);
    expect(stats.porEstado.funcional).toBe(1);
  });
});
