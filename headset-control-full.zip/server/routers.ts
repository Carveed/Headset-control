import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import * as db from "./db";
import { hashPassword, verifyPassword, generateToken } from "./auth";

// ─── Auth Router ──────────────────────────────────────────────────────────────
const authRouter = router({
  login: publicProcedure
    .input(z.object({ username: z.string(), password: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const user = await db.getUserByUsername(input.username);
      if (!user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Usuário ou senha inválidos" });

      const valid = await verifyPassword(input.password, user.passwordHash);
      if (!valid) throw new TRPCError({ code: "UNAUTHORIZED", message: "Usuário ou senha inválidos" });

      const token = await generateToken(user.id, user.role);

      ctx.res.cookie("auth_token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
        maxAge: 24 * 60 * 60 * 1000,
        path: "/",
      });

      return { success: true, user: { id: user.id, name: user.name, username: user.username, role: user.role } };
    }),

  logout: publicProcedure.mutation(({ ctx }) => {
    ctx.res.clearCookie("auth_token", { path: "/" });
    return { success: true };
  }),

  me: publicProcedure.query(({ ctx }) => {
    if (!ctx.user) return null;
    const { passwordHash: _, ...safeUser } = ctx.user;
    return safeUser;
  }),
});

// ─── Usuários Router (admin only) ─────────────────────────────────────────────
const usuariosRouter = router({
  list: adminProcedure.query(async () => {
    const users = await db.getAllUsers();
    return users.map(({ passwordHash: _, ...u }) => u);
  }),

  create: adminProcedure
    .input(
      z.object({
        username: z.string().min(3),
        password: z.string().min(6),
        name: z.string().min(2),
        role: z.enum(["user", "admin"]).default("user"),
      })
    )
    .mutation(async ({ input }) => {
      const existing = await db.getUserByUsername(input.username);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Usuário já existe" });

      const passwordHash = await hashPassword(input.password);
      const user = await db.createUser({ username: input.username, passwordHash, name: input.name, role: input.role });
      if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const { passwordHash: _, ...safeUser } = user;
      return safeUser;
    }),

  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.id === input.id) throw new TRPCError({ code: "BAD_REQUEST", message: "Não é possível excluir o próprio usuário" });
      await db.deleteUser(input.id);
      return { success: true };
    }),
});

// ─── Headsets Router ──────────────────────────────────────────────────────────
const headsetsRouter = router({
  list: protectedProcedure.query(async () => {
    return db.getAllHeadsets();
  }),

  create: protectedProcedure
    .input(
      z.object({
        patrimonio: z.string().min(1),
        serie: z.string().min(1),
        marca: z.string().min(1),
        estado: z.enum(["em_uso", "manutencao", "estoque", "funcional"]).default("estoque"),
        observacoes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return db.createHeadset(input);
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        patrimonio: z.string().min(1).optional(),
        serie: z.string().min(1).optional(),
        marca: z.string().min(1).optional(),
        estado: z.enum(["em_uso", "manutencao", "estoque", "funcional"]).optional(),
        observacoes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      return db.updateHeadset(id, data);
    }),

  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteHeadset(input.id);
      return { success: true };
    }),
});

// ─── Operadores Router ────────────────────────────────────────────────────────
const operadoresRouter = router({
  list: protectedProcedure.query(async () => {
    return db.getAllOperadores();
  }),

  create: protectedProcedure
    .input(
      z.object({
        nome: z.string().min(2),
        matricula: z.string().min(1),
        setor: z.string().optional(),
        telefone: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return db.createOperador({ ...input, ativo: true });
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        nome: z.string().min(2).optional(),
        matricula: z.string().min(1).optional(),
        setor: z.string().optional(),
        telefone: z.string().optional(),
        ativo: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      return db.updateOperador(id, data);
    }),

  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteOperador(input.id);
      return { success: true };
    }),
});

// ─── Vínculos Router ──────────────────────────────────────────────────────────
const vinculosRouter = router({
  listAtivos: protectedProcedure.query(async () => {
    const vinculos = await db.getVinculosAtivos();
    const headsets = await db.getAllHeadsets();
    const operadores = await db.getAllOperadores();

    return vinculos.map((v) => ({
      ...v,
      headset: headsets.find((h) => h.id === v.headsetId),
      operador: operadores.find((o) => o.id === v.operadorId),
    }));
  }),

  historico: protectedProcedure.query(async () => {
    const vinculos = await db.getHistoricoVinculos();
    const headsets = await db.getAllHeadsets();
    const operadores = await db.getAllOperadores();

    return vinculos.map((v) => ({
      ...v,
      headset: headsets.find((h) => h.id === v.headsetId),
      operador: operadores.find((o) => o.id === v.operadorId),
    }));
  }),

  vincular: protectedProcedure
    .input(
      z.object({
        headsetId: z.number(),
        operadorId: z.number(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Verificar se headset já está vinculado
      const vinculoExistente = await db.getVinculoByHeadsetId(input.headsetId);
      if (vinculoExistente) {
        throw new TRPCError({ code: "CONFLICT", message: "Este headset já está vinculado a um operador" });
      }

      // Criar vínculo
      const vinculo = await db.createVinculo({
        headsetId: input.headsetId,
        operadorId: input.operadorId,
        ativo: true,
        criadoPor: ctx.user.id,
      });

      // Atualizar estado do headset para em_uso
      await db.updateHeadset(input.headsetId, { estado: "em_uso" });

      return vinculo;
    }),

  desvincular: protectedProcedure
    .input(
      z.object({
        vinculoId: z.number(),
        motivoBaixa: z.string().optional(),
        desligarOperador: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const vinculos = await db.getVinculosAtivos();
      const vinculo = vinculos.find((v) => v.id === input.vinculoId);
      if (!vinculo) throw new TRPCError({ code: "NOT_FOUND", message: "Vínculo não encontrado" });

      await db.desativarVinculo(input.vinculoId, input.motivoBaixa);

      // Atualizar estado do headset para funcional (disponível)
      await db.updateHeadset(vinculo.headsetId, { estado: "funcional" });

      // Se operador foi desligado, marcar como inativo
      if (input.desligarOperador) {
        await db.updateOperador(vinculo.operadorId, { ativo: false });
      }

      return { success: true };
    }),
});

// ─── Dashboard Router ─────────────────────────────────────────────────────────
const dashboardRouter = router({
  stats: protectedProcedure.query(async () => {
    const headsets = await db.getAllHeadsets();
    const operadores = await db.getAllOperadores();
    const vinculos = await db.getVinculosAtivos();

    const porEstado = {
      em_uso: headsets.filter((h) => h.estado === "em_uso").length,
      manutencao: headsets.filter((h) => h.estado === "manutencao").length,
      estoque: headsets.filter((h) => h.estado === "estoque").length,
      funcional: headsets.filter((h) => h.estado === "funcional").length,
    };

    return {
      totalHeadsets: headsets.length,
      totalOperadores: operadores.length,
      operadoresAtivos: operadores.filter((o) => o.ativo).length,
      headsetsVinculados: vinculos.length,
      headsetsDisponiveis: headsets.filter((h) => h.estado !== "em_uso").length,
      porEstado,
    };
  }),
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  usuarios: usuariosRouter,
  headsets: headsetsRouter,
  operadores: operadoresRouter,
  vinculos: vinculosRouter,
  dashboard: dashboardRouter,
});

export type AppRouter = typeof appRouter;
