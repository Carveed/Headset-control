import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  users,
  headsets,
  operadores,
  vinculos,
  InsertUser,
  InsertHeadset,
  InsertOperador,
  InsertVinculo,
  type User,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Usuários ─────────────────────────────────────────────────────────────────

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users);
}

export async function createUser(data: InsertUser) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(users).values(data);
  return getUserByUsername(data.username);
}

export async function deleteUser(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(users).where(eq(users.id, id));
}

// ─── Headsets ─────────────────────────────────────────────────────────────────

export async function getAllHeadsets() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(headsets);
}

export async function getHeadsetById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(headsets).where(eq(headsets.id, id)).limit(1);
  return result[0];
}

export async function createHeadset(data: InsertHeadset) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(headsets).values(data);
  const result = await db
    .select()
    .from(headsets)
    .where(eq(headsets.patrimonio, data.patrimonio))
    .limit(1);
  return result[0];
}

export async function updateHeadset(id: number, data: Partial<InsertHeadset>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(headsets).set(data).where(eq(headsets.id, id));
  return getHeadsetById(id);
}

export async function deleteHeadset(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(headsets).where(eq(headsets.id, id));
}

// ─── Operadores ───────────────────────────────────────────────────────────────

export async function getAllOperadores() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(operadores);
}

export async function getOperadorById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(operadores)
    .where(eq(operadores.id, id))
    .limit(1);
  return result[0];
}

export async function createOperador(data: InsertOperador) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(operadores).values(data);
  const result = await db
    .select()
    .from(operadores)
    .where(eq(operadores.matricula, data.matricula))
    .limit(1);
  return result[0];
}

export async function updateOperador(id: number, data: Partial<InsertOperador>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(operadores).set(data).where(eq(operadores.id, id));
  return getOperadorById(id);
}

export async function deleteOperador(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(operadores).where(eq(operadores.id, id));
}

// ─── Vínculos ─────────────────────────────────────────────────────────────────

export async function getVinculosAtivos() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(vinculos)
    .where(eq(vinculos.ativo, true));
}

export async function getVinculoByHeadsetId(headsetId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(vinculos)
    .where(and(eq(vinculos.headsetId, headsetId), eq(vinculos.ativo, true)))
    .limit(1);
  return result[0];
}

export async function getVinculosByOperadorId(operadorId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(vinculos)
    .where(and(eq(vinculos.operadorId, operadorId), eq(vinculos.ativo, true)));
}

export async function createVinculo(data: InsertVinculo) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(vinculos).values(data);
  const result = await db
    .select()
    .from(vinculos)
    .where(
      and(
        eq(vinculos.headsetId, data.headsetId),
        eq(vinculos.operadorId, data.operadorId),
        eq(vinculos.ativo, true)
      )
    )
    .limit(1);
  return result[0];
}

export async function desativarVinculo(id: number, motivoBaixa?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(vinculos)
    .set({
      ativo: false,
      dataDesvinculo: new Date(),
      motivoBaixa: motivoBaixa ?? null,
    })
    .where(eq(vinculos.id, id));
}

export async function getHistoricoVinculos() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(vinculos);
}

// ─── Compatibilidade com SDK core (OAuth) ─────────────────────────────────────
// O sistema usa autenticação local, mas o SDK core ainda referencia estas funções.
// Mantemos stubs para evitar erros de compilação.

export async function getUserByOpenId(_openId: string): Promise<User | undefined> {
  // Não utilizado no fluxo de auth local
  return undefined;
}

export async function upsertUser(_data: Record<string, unknown> & { openId?: string; lastSignedIn?: Date; name?: string | null; email?: string | null; loginMethod?: string | null }) {
  // Não utilizado no fluxo de auth local
  return;
}
