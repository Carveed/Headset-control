import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AppLayout from "./components/AppLayout";
import ProtectedRoute from "./components/ProtectedRoute";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Headsets from "./pages/Headsets";
import Operadores from "./pages/Operadores";
import Vinculos from "./pages/Vinculos";
import Usuarios from "./pages/Usuarios";
import NotFound from "./pages/NotFound";

function ProtectedPage({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute>
      <AppLayout>{children}</AppLayout>
    </ProtectedRoute>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/">
        {() => <ProtectedPage><Dashboard /></ProtectedPage>}
      </Route>
      <Route path="/headsets">
        {() => <ProtectedPage><Headsets /></ProtectedPage>}
      </Route>
      <Route path="/operadores">
        {() => <ProtectedPage><Operadores /></ProtectedPage>}
      </Route>
      <Route path="/vinculos">
        {() => <ProtectedPage><Vinculos /></ProtectedPage>}
      </Route>
      <Route path="/usuarios">
        {() => <ProtectedPage><Usuarios /></ProtectedPage>}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster theme="dark" position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
