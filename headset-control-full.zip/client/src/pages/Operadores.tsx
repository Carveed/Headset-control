import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Users, Search, UserCheck, UserX } from "lucide-react";
import { cn } from "@/lib/utils";

type OperadorForm = {
  nome: string;
  matricula: string;
  setor: string;
  telefone: string;
};

const emptyForm: OperadorForm = { nome: "", matricula: "", setor: "", telefone: "" };

export default function Operadores() {
  const { isAdmin } = useAuth();
  const utils = trpc.useUtils();
  const { data: operadores, isLoading } = trpc.operadores.list.useQuery();

  const [search, setSearch] = useState("");
  const [filterAtivo, setFilterAtivo] = useState<"todos" | "ativos" | "inativos">("todos");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<OperadorForm>(emptyForm);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const createMutation = trpc.operadores.create.useMutation({
    onSuccess: () => { utils.operadores.list.invalidate(); utils.dashboard.stats.invalidate(); toast.success("Operador cadastrado!"); setDialogOpen(false); setForm(emptyForm); },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.operadores.update.useMutation({
    onSuccess: () => { utils.operadores.list.invalidate(); utils.dashboard.stats.invalidate(); toast.success("Operador atualizado!"); setDialogOpen(false); setEditingId(null); setForm(emptyForm); },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.operadores.delete.useMutation({
    onSuccess: () => { utils.operadores.list.invalidate(); utils.dashboard.stats.invalidate(); toast.success("Operador excluído!"); setDeleteId(null); },
    onError: (e) => toast.error(e.message),
  });

  const toggleAtivoMutation = trpc.operadores.update.useMutation({
    onSuccess: () => { utils.operadores.list.invalidate(); utils.dashboard.stats.invalidate(); toast.success("Status atualizado!"); },
    onError: (e) => toast.error(e.message),
  });

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setDialogOpen(true); };
  const openEdit = (o: NonNullable<typeof operadores>[0]) => {
    setEditingId(o.id);
    setForm({ nome: o.nome, matricula: o.matricula, setor: o.setor || "", telefone: o.telefone || "" });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome || !form.matricula) { toast.error("Nome e matrícula são obrigatórios"); return; }
    if (editingId) updateMutation.mutate({ id: editingId, ...form });
    else createMutation.mutate(form);
  };

  const filtered = (operadores || []).filter((o) => {
    const matchSearch = !search || o.nome.toLowerCase().includes(search.toLowerCase()) || o.matricula.toLowerCase().includes(search.toLowerCase()) || (o.setor || "").toLowerCase().includes(search.toLowerCase());
    const matchAtivo = filterAtivo === "todos" || (filterAtivo === "ativos" ? o.ativo : !o.ativo);
    return matchSearch && matchAtivo;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight" style={{ textShadow: "0 2px 20px rgba(236,72,153,0.3)" }}>
            Operadores
          </h1>
          <p className="text-white/40 text-sm mt-1">{operadores?.length ?? 0} operadores cadastrados</p>
        </div>
        <Button onClick={openCreate} className="gap-2 text-white border-0 font-semibold"
          style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)", boxShadow: "0 4px 15px rgba(139,92,246,0.3)" }}>
          <Plus className="w-4 h-4" />
          Novo Operador
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <Input
            placeholder="Buscar por nome, matrícula ou setor..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/25 h-10"
          />
        </div>
        <div className="flex gap-2">
          {(["todos", "ativos", "inativos"] as const).map((f) => (
            <button key={f} onClick={() => setFilterAtivo(f)}
              className={cn("px-4 py-2 rounded-xl text-sm font-medium transition-all capitalize", filterAtivo === f ? "text-white" : "text-white/40 hover:text-white/70 bg-white/5")}
              style={filterAtivo === f ? { background: "linear-gradient(135deg, rgba(236,72,153,0.3), rgba(139,92,246,0.3))", border: "1px solid rgba(236,72,153,0.3)" } : {}}>
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="mesh-card rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="p-8 space-y-3">
            {[...Array(5)].map((_, i) => <div key={i} className="h-12 rounded-xl bg-white/5 animate-pulse" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Users className="w-12 h-12 text-white/15 mb-3" />
            <p className="text-white/40 font-medium">Nenhum operador encontrado</p>
            <p className="text-white/20 text-sm mt-1">Cadastre um novo operador para começar</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Operador</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Matrícula</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Setor</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Telefone</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Status</th>
                  <th className="text-right text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((o) => (
                  <tr key={o.id} className="border-b border-white/5 last:border-0 hover:bg-white/3 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                          style={{ background: "linear-gradient(135deg, rgba(139,92,246,0.5), rgba(59,130,246,0.5))" }}>
                          {o.nome.charAt(0).toUpperCase()}
                        </div>
                        <span className="text-white font-semibold text-sm">{o.nome}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-white/60 text-sm font-mono">{o.matricula}</td>
                    <td className="px-4 py-4 text-white/60 text-sm">{o.setor || "—"}</td>
                    <td className="px-4 py-4 text-white/60 text-sm">{o.telefone || "—"}</td>
                    <td className="px-4 py-4">
                      <button onClick={() => toggleAtivoMutation.mutate({ id: o.id, ativo: !o.ativo })}
                        className={cn("inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border transition-all hover:opacity-80",
                          o.ativo ? "text-green-400 bg-green-500/15 border-green-500/30" : "text-red-400 bg-red-500/15 border-red-500/30")}>
                        {o.ativo ? <UserCheck className="w-3 h-3" /> : <UserX className="w-3 h-3" />}
                        {o.ativo ? "Ativo" : "Inativo"}
                      </button>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(o)}
                          className="w-8 h-8 text-white/40 hover:text-blue-400 hover:bg-blue-500/10">
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        {isAdmin && (
                          <Button variant="ghost" size="icon" onClick={() => setDeleteId(o.id)}
                            className="w-8 h-8 text-white/40 hover:text-red-400 hover:bg-red-500/10">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) { setEditingId(null); setForm(emptyForm); } }}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white font-bold">{editingId ? "Editar Operador" : "Novo Operador"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Nome Completo *</Label>
              <Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })}
                placeholder="Nome do operador" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Matrícula *</Label>
              <Input value={form.matricula} onChange={(e) => setForm({ ...form, matricula: e.target.value })}
                placeholder="Ex: MAT-001" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-white/70 text-sm">Setor</Label>
                <Input value={form.setor} onChange={(e) => setForm({ ...form, setor: e.target.value })}
                  placeholder="Ex: Atendimento" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-white/70 text-sm">Telefone</Label>
                <Input value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })}
                  placeholder="Ex: (51) 99999-9999" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
              </div>
            </div>
            <DialogFooter className="gap-2 mt-2">
              <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)} className="text-white/50 hover:text-white">Cancelar</Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}
                className="text-white border-0 font-semibold"
                style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)" }}>
                {createMutation.isPending || updateMutation.isPending ? "Salvando..." : editingId ? "Salvar" : "Cadastrar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Dialog */}
      <Dialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white font-bold">Confirmar Exclusão</DialogTitle>
          </DialogHeader>
          <p className="text-white/60 text-sm">Tem certeza que deseja excluir este operador?</p>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setDeleteId(null)} className="text-white/50 hover:text-white">Cancelar</Button>
            <Button onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              disabled={deleteMutation.isPending}
              className="bg-red-500/80 hover:bg-red-500 text-white border-0">
              {deleteMutation.isPending ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
