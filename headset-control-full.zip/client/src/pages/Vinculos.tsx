import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Link2, Link2Off, Plus, Headphones, Users, History, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Vinculos() {
  const utils = trpc.useUtils();
  const { data: vinculos, isLoading } = trpc.vinculos.listAtivos.useQuery();
  const { data: historico } = trpc.vinculos.historico.useQuery();
  const { data: headsets } = trpc.headsets.list.useQuery();
  const { data: operadores } = trpc.operadores.list.useQuery();

  const [tab, setTab] = useState<"ativos" | "historico">("ativos");
  const [vincularOpen, setVincularOpen] = useState(false);
  const [desvincularId, setDesvincularId] = useState<number | null>(null);
  const [selectedHeadset, setSelectedHeadset] = useState("");
  const [selectedOperador, setSelectedOperador] = useState("");
  const [motivoBaixa, setMotivoBaixa] = useState("");
  const [desligarOperador, setDesligarOperador] = useState(false);

  const vincularMutation = trpc.vinculos.vincular.useMutation({
    onSuccess: () => {
      utils.vinculos.listAtivos.invalidate();
      utils.vinculos.historico.invalidate();
      utils.headsets.list.invalidate();
      utils.dashboard.stats.invalidate();
      toast.success("Headset vinculado com sucesso!");
      setVincularOpen(false);
      setSelectedHeadset("");
      setSelectedOperador("");
    },
    onError: (e) => toast.error(e.message),
  });

  const desvincularMutation = trpc.vinculos.desvincular.useMutation({
    onSuccess: () => {
      utils.vinculos.listAtivos.invalidate();
      utils.vinculos.historico.invalidate();
      utils.headsets.list.invalidate();
      utils.operadores.list.invalidate();
      utils.dashboard.stats.invalidate();
      toast.success("Headset desvinculado (baixa realizada)!");
      setDesvincularId(null);
      setMotivoBaixa("");
      setDesligarOperador(false);
    },
    onError: (e) => toast.error(e.message),
  });

  // Headsets disponíveis (não em uso)
  const headsetsDisponiveis = (headsets || []).filter((h) => h.estado !== "em_uso");
  // Operadores ativos
  const operadoresAtivos = (operadores || []).filter((o) => o.ativo);

  const handleVincular = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHeadset || !selectedOperador) { toast.error("Selecione o headset e o operador"); return; }
    vincularMutation.mutate({ headsetId: parseInt(selectedHeadset), operadorId: parseInt(selectedOperador) });
  };

  const handleDesvincular = () => {
    if (!desvincularId) return;
    desvincularMutation.mutate({ vinculoId: desvincularId, motivoBaixa, desligarOperador });
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "—";
    return new Date(date).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight" style={{ textShadow: "0 2px 20px rgba(236,72,153,0.3)" }}>
            Vínculos
          </h1>
          <p className="text-white/40 text-sm mt-1">{vinculos?.length ?? 0} vínculos ativos</p>
        </div>
        <Button onClick={() => setVincularOpen(true)} className="gap-2 text-white border-0 font-semibold"
          style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)", boxShadow: "0 4px 15px rgba(139,92,246,0.3)" }}>
          <Plus className="w-4 h-4" />
          Vincular Headset
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        <button onClick={() => setTab("ativos")}
          className={cn("flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all", tab === "ativos" ? "text-white" : "text-white/40 hover:text-white/70 bg-white/5")}
          style={tab === "ativos" ? { background: "linear-gradient(135deg, rgba(236,72,153,0.3), rgba(139,92,246,0.3))", border: "1px solid rgba(236,72,153,0.3)" } : {}}>
          <Link2 className="w-4 h-4" />
          Vínculos Ativos
        </button>
        <button onClick={() => setTab("historico")}
          className={cn("flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all", tab === "historico" ? "text-white" : "text-white/40 hover:text-white/70 bg-white/5")}
          style={tab === "historico" ? { background: "linear-gradient(135deg, rgba(236,72,153,0.3), rgba(139,92,246,0.3))", border: "1px solid rgba(236,72,153,0.3)" } : {}}>
          <History className="w-4 h-4" />
          Histórico Completo
        </button>
      </div>

      {/* Ativos Table */}
      {tab === "ativos" && (
        <div className="mesh-card rounded-2xl overflow-hidden">
          {isLoading ? (
            <div className="p-8 space-y-3">
              {[...Array(4)].map((_, i) => <div key={i} className="h-12 rounded-xl bg-white/5 animate-pulse" />)}
            </div>
          ) : !vinculos || vinculos.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Link2 className="w-12 h-12 text-white/15 mb-3" />
              <p className="text-white/40 font-medium">Nenhum vínculo ativo</p>
              <p className="text-white/20 text-sm mt-1">Vincule um headset a um operador para começar</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Headset</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Operador</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Setor</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Data do Vínculo</th>
                    <th className="text-right text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {vinculos.map((v) => (
                    <tr key={v.id} className="border-b border-white/5 last:border-0 hover:bg-white/3 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                            style={{ background: "linear-gradient(135deg, rgba(236,72,153,0.3), rgba(139,92,246,0.3))" }}>
                            <Headphones className="w-4 h-4 text-pink-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">#{v.headset?.patrimonio || "—"}</p>
                            <p className="text-white/40 text-xs">{v.headset?.marca || "—"}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                            style={{ background: "linear-gradient(135deg, rgba(139,92,246,0.5), rgba(59,130,246,0.5))" }}>
                            {v.operador?.nome?.charAt(0)?.toUpperCase() || "?"}
                          </div>
                          <div>
                            <p className="text-white text-sm font-medium">{v.operador?.nome || "—"}</p>
                            <p className="text-white/40 text-xs">{v.operador?.matricula || "—"}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-white/60 text-sm">{v.operador?.setor || "—"}</td>
                      <td className="px-4 py-4 text-white/60 text-sm">{formatDate(v.dataVinculo)}</td>
                      <td className="px-6 py-4">
                        <Button variant="ghost" size="sm" onClick={() => setDesvincularId(v.id)}
                          className="gap-1.5 text-red-400/70 hover:text-red-400 hover:bg-red-500/10 text-xs">
                          <Link2Off className="w-3.5 h-3.5" />
                          Dar Baixa
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Histórico Table */}
      {tab === "historico" && (
        <div className="mesh-card rounded-2xl overflow-hidden">
          {!historico || historico.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <History className="w-12 h-12 text-white/15 mb-3" />
              <p className="text-white/40 font-medium">Nenhum histórico disponível</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Headset</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Operador</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Vínculo</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Baixa</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Status</th>
                    <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Motivo</th>
                  </tr>
                </thead>
                <tbody>
                  {historico.map((v) => (
                    <tr key={v.id} className="border-b border-white/5 last:border-0 hover:bg-white/3 transition-colors">
                      <td className="px-6 py-4">
                        <p className="text-white font-semibold text-sm">#{v.headset?.patrimonio || "—"}</p>
                        <p className="text-white/40 text-xs">{v.headset?.marca || "—"}</p>
                      </td>
                      <td className="px-4 py-4">
                        <p className="text-white text-sm">{v.operador?.nome || "—"}</p>
                        <p className="text-white/40 text-xs">{v.operador?.matricula || "—"}</p>
                      </td>
                      <td className="px-4 py-4 text-white/60 text-xs">{formatDate(v.dataVinculo)}</td>
                      <td className="px-4 py-4 text-white/60 text-xs">{formatDate(v.dataDesvinculo)}</td>
                      <td className="px-4 py-4">
                        <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border",
                          v.ativo ? "text-green-400 bg-green-500/15 border-green-500/30" : "text-white/40 bg-white/5 border-white/10")}>
                          {v.ativo ? "Ativo" : "Encerrado"}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-white/50 text-xs max-w-[150px] truncate">{v.motivoBaixa || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Vincular Dialog */}
      <Dialog open={vincularOpen} onOpenChange={(o) => { setVincularOpen(o); if (!o) { setSelectedHeadset(""); setSelectedOperador(""); } }}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white font-bold flex items-center gap-2">
              <Link2 className="w-5 h-5 text-pink-400" />
              Vincular Headset a Operador
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleVincular} className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm flex items-center gap-2">
                <Headphones className="w-3.5 h-3.5 text-pink-400" />
                Headset Disponível *
              </Label>
              <Select value={selectedHeadset} onValueChange={setSelectedHeadset}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue placeholder="Selecione um headset..." />
                </SelectTrigger>
                <SelectContent>
                  {headsetsDisponiveis.length === 0 ? (
                    <SelectItem value="none" disabled>Nenhum headset disponível</SelectItem>
                  ) : (
                    headsetsDisponiveis.map((h) => (
                      <SelectItem key={h.id} value={String(h.id)}>
                        #{h.patrimonio} — {h.marca} ({h.estado})
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm flex items-center gap-2">
                <Users className="w-3.5 h-3.5 text-violet-400" />
                Operador *
              </Label>
              <Select value={selectedOperador} onValueChange={setSelectedOperador}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue placeholder="Selecione um operador..." />
                </SelectTrigger>
                <SelectContent>
                  {operadoresAtivos.length === 0 ? (
                    <SelectItem value="none" disabled>Nenhum operador ativo</SelectItem>
                  ) : (
                    operadoresAtivos.map((o) => (
                      <SelectItem key={o.id} value={String(o.id)}>
                        {o.nome} — {o.matricula}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
            {headsetsDisponiveis.length === 0 && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
                <AlertCircle className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                <p className="text-yellow-400/80 text-xs">Não há headsets disponíveis para vincular.</p>
              </div>
            )}
            <DialogFooter className="gap-2 mt-2">
              <Button type="button" variant="ghost" onClick={() => setVincularOpen(false)} className="text-white/50 hover:text-white">Cancelar</Button>
              <Button type="submit" disabled={vincularMutation.isPending || headsetsDisponiveis.length === 0}
                className="text-white border-0 font-semibold"
                style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)" }}>
                {vincularMutation.isPending ? "Vinculando..." : "Vincular"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Desvincular Dialog */}
      <Dialog open={!!desvincularId} onOpenChange={(o) => { if (!o) { setDesvincularId(null); setMotivoBaixa(""); setDesligarOperador(false); } }}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white font-bold flex items-center gap-2">
              <Link2Off className="w-5 h-5 text-red-400" />
              Dar Baixa no Headset
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <p className="text-white/60 text-sm">Esta ação irá desvincular o headset do operador e registrar a baixa no histórico.</p>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Motivo da Baixa</Label>
              <Input value={motivoBaixa} onChange={(e) => setMotivoBaixa(e.target.value)}
                placeholder="Ex: Operador desligado, defeito, etc."
                className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <label className="flex items-center gap-3 cursor-pointer group">
              <div onClick={() => setDesligarOperador(!desligarOperador)}
                className={cn("w-5 h-5 rounded border-2 flex items-center justify-center transition-all flex-shrink-0",
                  desligarOperador ? "border-red-400 bg-red-500/20" : "border-white/20 bg-white/5")}>
                {desligarOperador && <div className="w-2.5 h-2.5 rounded-sm bg-red-400" />}
              </div>
              <div>
                <p className="text-white/70 text-sm font-medium">Marcar operador como inativo</p>
                <p className="text-white/30 text-xs">Selecione se o operador foi desligado da empresa</p>
              </div>
            </label>
          </div>
          <DialogFooter className="gap-2 mt-2">
            <Button variant="ghost" onClick={() => setDesvincularId(null)} className="text-white/50 hover:text-white">Cancelar</Button>
            <Button onClick={handleDesvincular} disabled={desvincularMutation.isPending}
              className="bg-red-500/80 hover:bg-red-500 text-white border-0 gap-1.5">
              <Link2Off className="w-4 h-4" />
              {desvincularMutation.isPending ? "Processando..." : "Confirmar Baixa"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
