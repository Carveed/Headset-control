import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Headphones, Search, Package } from "lucide-react";
import { cn } from "@/lib/utils";

type Estado = "em_uso" | "manutencao" | "estoque" | "funcional";

const estadoConfig: Record<Estado, { label: string; color: string; bg: string }> = {
  em_uso: { label: "Em Uso", color: "text-pink-400", bg: "bg-pink-500/15 border-pink-500/30" },
  manutencao: { label: "Manutenção", color: "text-yellow-400", bg: "bg-yellow-500/15 border-yellow-500/30" },
  estoque: { label: "Estoque", color: "text-blue-400", bg: "bg-blue-500/15 border-blue-500/30" },
  funcional: { label: "Funcional", color: "text-green-400", bg: "bg-green-500/15 border-green-500/30" },
};

function EstadoBadge({ estado }: { estado: Estado }) {
  const cfg = estadoConfig[estado];
  return (
    <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border", cfg.bg, cfg.color)}>
      {cfg.label}
    </span>
  );
}

type HeadsetForm = {
  patrimonio: string;
  serie: string;
  marca: string;
  estado: Estado;
  observacoes: string;
};

const emptyForm: HeadsetForm = { patrimonio: "", serie: "", marca: "", estado: "estoque", observacoes: "" };

export default function Headsets() {
  const { isAdmin } = useAuth();
  const utils = trpc.useUtils();
  const { data: headsets, isLoading } = trpc.headsets.list.useQuery();

  const [search, setSearch] = useState("");
  const [filterEstado, setFilterEstado] = useState<string>("todos");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<HeadsetForm>(emptyForm);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const createMutation = trpc.headsets.create.useMutation({
    onSuccess: () => { utils.headsets.list.invalidate(); toast.success("Headset cadastrado!"); setDialogOpen(false); setForm(emptyForm); },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.headsets.update.useMutation({
    onSuccess: () => { utils.headsets.list.invalidate(); utils.dashboard.stats.invalidate(); toast.success("Headset atualizado!"); setDialogOpen(false); setEditingId(null); setForm(emptyForm); },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.headsets.delete.useMutation({
    onSuccess: () => { utils.headsets.list.invalidate(); utils.dashboard.stats.invalidate(); toast.success("Headset excluído!"); setDeleteId(null); },
    onError: (e) => toast.error(e.message),
  });

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setDialogOpen(true); };
  const openEdit = (h: NonNullable<typeof headsets>[0]) => {
    setEditingId(h.id);
    setForm({ patrimonio: h.patrimonio, serie: h.serie, marca: h.marca, estado: h.estado as Estado, observacoes: h.observacoes || "" });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.patrimonio || !form.serie || !form.marca) { toast.error("Preencha todos os campos obrigatórios"); return; }
    if (editingId) updateMutation.mutate({ id: editingId, ...form });
    else createMutation.mutate(form);
  };

  const filtered = (headsets || []).filter((h) => {
    const matchSearch = !search || h.patrimonio.toLowerCase().includes(search.toLowerCase()) || h.marca.toLowerCase().includes(search.toLowerCase()) || h.serie.toLowerCase().includes(search.toLowerCase());
    const matchEstado = filterEstado === "todos" || h.estado === filterEstado;
    return matchSearch && matchEstado;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight" style={{ textShadow: "0 2px 20px rgba(236,72,153,0.3)" }}>
            Headsets
          </h1>
          <p className="text-white/40 text-sm mt-1">{headsets?.length ?? 0} equipamentos cadastrados</p>
        </div>
        <Button onClick={openCreate} className="gap-2 text-white border-0 font-semibold"
          style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)", boxShadow: "0 4px 15px rgba(139,92,246,0.3)" }}>
          <Plus className="w-4 h-4" />
          Novo Headset
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <Input
            placeholder="Buscar por patrimônio, marca ou série..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/25 h-10"
          />
        </div>
        <Select value={filterEstado} onValueChange={setFilterEstado}>
          <SelectTrigger className="w-full sm:w-44 bg-white/5 border-white/10 text-white h-10">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os estados</SelectItem>
            <SelectItem value="em_uso">Em Uso</SelectItem>
            <SelectItem value="funcional">Funcional</SelectItem>
            <SelectItem value="estoque">Estoque</SelectItem>
            <SelectItem value="manutencao">Manutenção</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="mesh-card rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="p-8 space-y-3">
            {[...Array(5)].map((_, i) => <div key={i} className="h-12 rounded-xl bg-white/5 animate-pulse" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Package className="w-12 h-12 text-white/15 mb-3" />
            <p className="text-white/40 font-medium">Nenhum headset encontrado</p>
            <p className="text-white/20 text-sm mt-1">Cadastre um novo headset para começar</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Patrimônio</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Número de Série</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Marca</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Estado</th>
                  <th className="text-right text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((h) => (
                  <tr key={h.id} className="border-b border-white/5 last:border-0 hover:bg-white/3 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{ background: "linear-gradient(135deg, rgba(236,72,153,0.3), rgba(139,92,246,0.3))" }}>
                          <Headphones className="w-4 h-4 text-pink-400" />
                        </div>
                        <span className="text-white font-semibold text-sm">{h.patrimonio}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-white/60 text-sm font-mono">{h.serie}</td>
                    <td className="px-4 py-4 text-white/80 text-sm">{h.marca}</td>
                    <td className="px-4 py-4"><EstadoBadge estado={h.estado as Estado} /></td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(h)}
                          className="w-8 h-8 text-white/40 hover:text-blue-400 hover:bg-blue-500/10">
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        {isAdmin && (
                          <Button variant="ghost" size="icon" onClick={() => setDeleteId(h.id)}
                            className="w-8 h-8 text-white/40 hover:text-red-400 hover:bg-red-500/10">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) { setEditingId(null); setForm(emptyForm); } }}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white font-bold">{editingId ? "Editar Headset" : "Novo Headset"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Número de Patrimônio *</Label>
              <Input value={form.patrimonio} onChange={(e) => setForm({ ...form, patrimonio: e.target.value })}
                placeholder="Ex: PAT-001" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Número de Série *</Label>
              <Input value={form.serie} onChange={(e) => setForm({ ...form, serie: e.target.value })}
                placeholder="Ex: SN123456789" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Marca *</Label>
              <Input value={form.marca} onChange={(e) => setForm({ ...form, marca: e.target.value })}
                placeholder="Ex: Jabra, Plantronics, Logitech" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Estado</Label>
              <Select value={form.estado} onValueChange={(v) => setForm({ ...form, estado: v as Estado })}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="estoque">Estoque</SelectItem>
                  <SelectItem value="funcional">Funcional</SelectItem>
                  <SelectItem value="em_uso">Em Uso</SelectItem>
                  <SelectItem value="manutencao">Manutenção</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Observações</Label>
              <Input value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
                placeholder="Observações opcionais..." className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <DialogFooter className="gap-2 mt-2">
              <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)} className="text-white/50 hover:text-white">Cancelar</Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}
                className="text-white border-0 font-semibold"
                style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)" }}>
                {createMutation.isPending || updateMutation.isPending ? "Salvando..." : editingId ? "Salvar" : "Cadastrar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Dialog */}
      <Dialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white font-bold">Confirmar Exclusão</DialogTitle>
          </DialogHeader>
          <p className="text-white/60 text-sm">Tem certeza que deseja excluir este headset? Esta ação não pode ser desfeita.</p>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setDeleteId(null)} className="text-white/50 hover:text-white">Cancelar</Button>
            <Button onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              disabled={deleteMutation.isPending}
              className="bg-red-500/80 hover:bg-red-500 text-white border-0">
              {deleteMutation.isPending ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
