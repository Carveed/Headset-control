import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Trash2, Settings, ShieldCheck, User, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

type UserForm = {
  username: string;
  password: string;
  name: string;
  role: "user" | "admin";
};

const emptyForm: UserForm = { username: "", password: "", name: "", role: "user" };

export default function Usuarios() {
  const { user: currentUser } = useAuth();
  const utils = trpc.useUtils();
  const { data: usuarios, isLoading } = trpc.usuarios.list.useQuery();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<UserForm>(emptyForm);
  const [showPassword, setShowPassword] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const createMutation = trpc.usuarios.create.useMutation({
    onSuccess: () => {
      utils.usuarios.list.invalidate();
      toast.success("Usuário criado com sucesso!");
      setDialogOpen(false);
      setForm(emptyForm);
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.usuarios.delete.useMutation({
    onSuccess: () => {
      utils.usuarios.list.invalidate();
      toast.success("Usuário removido!");
      setDeleteId(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.username || !form.password || !form.name) { toast.error("Preencha todos os campos"); return; }
    if (form.password.length < 6) { toast.error("A senha deve ter pelo menos 6 caracteres"); return; }
    createMutation.mutate(form);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight" style={{ textShadow: "0 2px 20px rgba(236,72,153,0.3)" }}>
            Usuários do Sistema
          </h1>
          <p className="text-white/40 text-sm mt-1">Gerenciamento de acesso ao sistema</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-2 text-white border-0 font-semibold"
          style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)", boxShadow: "0 4px 15px rgba(139,92,246,0.3)" }}>
          <Plus className="w-4 h-4" />
          Novo Usuário
        </Button>
      </div>

      {/* Info Card */}
      <div className="mesh-card rounded-2xl p-4 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-violet-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-white/70 text-sm font-medium">Acesso restrito a administradores</p>
          <p className="text-white/40 text-xs mt-0.5">Apenas administradores podem criar, visualizar e remover usuários do sistema.</p>
        </div>
      </div>

      {/* Table */}
      <div className="mesh-card rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="p-8 space-y-3">
            {[...Array(3)].map((_, i) => <div key={i} className="h-12 rounded-xl bg-white/5 animate-pulse" />)}
          </div>
        ) : !usuarios || usuarios.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Settings className="w-12 h-12 text-white/15 mb-3" />
            <p className="text-white/40 font-medium">Nenhum usuário cadastrado</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Usuário</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Login</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Perfil</th>
                  <th className="text-left text-white/40 text-xs font-semibold uppercase tracking-wider px-4 py-4">Criado em</th>
                  <th className="text-right text-white/40 text-xs font-semibold uppercase tracking-wider px-6 py-4">Ações</th>
                </tr>
              </thead>
              <tbody>
                {usuarios.map((u) => (
                  <tr key={u.id} className="border-b border-white/5 last:border-0 hover:bg-white/3 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0",
                          u.role === "admin" ? "" : "")}
                          style={{ background: u.role === "admin" ? "linear-gradient(135deg, #ec4899, #8b5cf6)" : "linear-gradient(135deg, rgba(139,92,246,0.5), rgba(59,130,246,0.5))" }}>
                          {u.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-white font-semibold text-sm">{u.name}</p>
                          {u.id === currentUser?.id && <p className="text-white/30 text-xs">Você</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-white/60 text-sm font-mono">{u.username}</td>
                    <td className="px-4 py-4">
                      <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border",
                        u.role === "admin" ? "text-pink-400 bg-pink-500/15 border-pink-500/30" : "text-blue-400 bg-blue-500/15 border-blue-500/30")}>
                        {u.role === "admin" ? <ShieldCheck className="w-3 h-3" /> : <User className="w-3 h-3" />}
                        {u.role === "admin" ? "Administrador" : "Usuário"}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-white/50 text-sm">
                      {new Date(u.createdAt).toLocaleDateString("pt-BR")}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end">
                        {u.id !== currentUser?.id ? (
                          <Button variant="ghost" size="icon" onClick={() => setDeleteId(u.id)}
                            className="w-8 h-8 text-white/40 hover:text-red-400 hover:bg-red-500/10">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        ) : (
                          <span className="text-white/20 text-xs px-2">—</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) setForm(emptyForm); }}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white font-bold">Novo Usuário</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Nome Completo *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Nome do usuário" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Login (usuário) *</Label>
              <Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })}
                placeholder="Nome de usuário para login" className="bg-white/5 border-white/10 text-white placeholder:text-white/25" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Senha *</Label>
              <div className="relative">
                <Input type={showPassword ? "text" : "password"} value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="Mínimo 6 caracteres" className="pr-10 bg-white/5 border-white/10 text-white placeholder:text-white/25" />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/70 text-sm">Perfil</Label>
              <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as "user" | "admin" })}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Usuário</SelectItem>
                  <SelectItem value="admin">Administrador</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter className="gap-2 mt-2">
              <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)} className="text-white/50 hover:text-white">Cancelar</Button>
              <Button type="submit" disabled={createMutation.isPending}
                className="text-white border-0 font-semibold"
                style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)" }}>
                {createMutation.isPending ? "Criando..." : "Criar Usuário"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <DialogContent className="bg-[#0e0e1f] border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white font-bold">Remover Usuário</DialogTitle>
          </DialogHeader>
          <p className="text-white/60 text-sm">Tem certeza que deseja remover este usuário do sistema?</p>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setDeleteId(null)} className="text-white/50 hover:text-white">Cancelar</Button>
            <Button onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              disabled={deleteMutation.isPending}
              className="bg-red-500/80 hover:bg-red-500 text-white border-0">
              {deleteMutation.isPending ? "Removendo..." : "Remover"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
