import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Headphones, Users, Link2, Package, Wrench, CheckCircle, AlertCircle } from "lucide-react";

function StatCard({
  label,
  value,
  icon: Icon,
  color,
  sub,
}: {
  label: string;
  value: number | string;
  icon: React.ElementType;
  color: string;
  sub?: string;
}) {
  return (
    <div className="mesh-card rounded-2xl p-6 hover:border-white/15 transition-all duration-300">
      <div className="flex items-start justify-between mb-4">
        <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: color }}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <span className="text-3xl font-black text-white">{value}</span>
      </div>
      <p className="text-white/60 text-sm font-medium">{label}</p>
      {sub && <p className="text-white/30 text-xs mt-1">{sub}</p>}
    </div>
  );
}

function EstadoBadge({ label, count, color }: { label: string; count: number; color: string }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
      <div className="flex items-center gap-3">
        <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: color }} />
        <span className="text-white/70 text-sm">{label}</span>
      </div>
      <span className="text-white font-bold text-sm">{count}</span>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  const { data: vinculos } = trpc.vinculos.listAtivos.useQuery();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-10 w-64 rounded-xl bg-white/5 animate-pulse" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-32 rounded-2xl bg-white/5 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-black text-white tracking-tight"
          style={{ textShadow: "0 2px 20px rgba(236,72,153,0.3)" }}>
          Dashboard
        </h1>
        <p className="text-white/40 text-sm mt-1 tracking-wide">
          Bem-vindo, <span className="text-white/70 font-medium">{user?.name}</span> · Visão geral do sistema
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total de Headsets"
          value={stats?.totalHeadsets ?? 0}
          icon={Headphones}
          color="linear-gradient(135deg, #ec4899, #8b5cf6)"
          sub="equipamentos cadastrados"
        />
        <StatCard
          label="Em Uso"
          value={stats?.headsetsVinculados ?? 0}
          icon={Link2}
          color="linear-gradient(135deg, #8b5cf6, #3b82f6)"
          sub="vinculados a operadores"
        />
        <StatCard
          label="Disponíveis"
          value={stats?.headsetsDisponiveis ?? 0}
          icon={Package}
          color="linear-gradient(135deg, #10b981, #059669)"
          sub="prontos para uso"
        />
        <StatCard
          label="Operadores Ativos"
          value={stats?.operadoresAtivos ?? 0}
          icon={Users}
          color="linear-gradient(135deg, #f59e0b, #d97706)"
          sub={`de ${stats?.totalOperadores ?? 0} cadastrados`}
        />
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Estado dos Headsets */}
        <div className="mesh-card rounded-2xl p-6">
          <h2 className="text-white font-bold text-base mb-5 flex items-center gap-2">
            <Headphones className="w-4 h-4 text-pink-400" />
            Headsets por Estado
          </h2>
          <EstadoBadge label="Em Uso" count={stats?.porEstado.em_uso ?? 0} color="#ec4899" />
          <EstadoBadge label="Funcional (Disponível)" count={stats?.porEstado.funcional ?? 0} color="#10b981" />
          <EstadoBadge label="Em Estoque" count={stats?.porEstado.estoque ?? 0} color="#3b82f6" />
          <EstadoBadge label="Em Manutenção" count={stats?.porEstado.manutencao ?? 0} color="#f59e0b" />
        </div>

        {/* Vínculos Ativos */}
        <div className="mesh-card rounded-2xl p-6">
          <h2 className="text-white font-bold text-base mb-5 flex items-center gap-2">
            <Link2 className="w-4 h-4 text-violet-400" />
            Vínculos Ativos Recentes
          </h2>
          {vinculos && vinculos.length > 0 ? (
            <div className="space-y-3">
              {vinculos.slice(0, 5).map((v) => (
                <div key={v.id} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                    style={{ background: "linear-gradient(135deg, #8b5cf6, #3b82f6)" }}>
                    {v.operador?.nome?.charAt(0)?.toUpperCase() || "?"}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-white text-sm font-medium truncate">{v.operador?.nome || "—"}</p>
                    <p className="text-white/40 text-xs truncate">Headset #{v.headset?.patrimonio || "—"} · {v.headset?.marca || "—"}</p>
                  </div>
                  <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                </div>
              ))}
              {vinculos.length > 5 && (
                <p className="text-white/30 text-xs text-center pt-1">+{vinculos.length - 5} outros vínculos ativos</p>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <AlertCircle className="w-8 h-8 text-white/20 mb-2" />
              <p className="text-white/30 text-sm">Nenhum vínculo ativo</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
