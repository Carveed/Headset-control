import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard,
  Headphones,
  Users,
  Link2,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/headsets", icon: Headphones, label: "Headsets" },
  { href: "/operadores", icon: Users, label: "Operadores" },
  { href: "/vinculos", icon: Link2, label: "Vínculos" },
  { href: "/usuarios", icon: Settings, label: "Usuários", adminOnly: true },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout, isAdmin } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const filteredNav = navItems.filter((item) => !item.adminOnly || isAdmin);

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-6 py-6 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)" }}>
            <Headphones className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-black text-white text-sm leading-none">HeadsetControl</p>
            <p className="text-white/30 text-xs mt-0.5">Gestão de Equipamentos</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {filteredNav.map((item) => {
          const active = location === item.href || (item.href !== "/" && location.startsWith(item.href));
          return (
            <Link key={item.href} href={item.href}>
              <a
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group",
                  active
                    ? "text-white"
                    : "text-white/50 hover:text-white/80 hover:bg-white/5"
                )}
                style={active ? {
                  background: "linear-gradient(135deg, rgba(236,72,153,0.2), rgba(139,92,246,0.2))",
                  borderLeft: "2px solid #ec4899",
                } : {}}
              >
                <item.icon className={cn("w-4 h-4 flex-shrink-0", active ? "text-pink-400" : "text-white/40 group-hover:text-white/60")} />
                <span>{item.label}</span>
                {active && <ChevronRight className="w-3 h-3 ml-auto text-pink-400/60" />}
              </a>
            </Link>
          );
        })}
      </nav>

      {/* User */}
      <div className="px-3 py-4 border-t border-white/5">
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-white/5 mb-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
            style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)" }}>
            {user?.name?.charAt(0)?.toUpperCase() || "U"}
          </div>
          <div className="min-w-0">
            <p className="text-white text-xs font-semibold truncate">{user?.name}</p>
            <p className="text-white/30 text-xs truncate">{user?.role === "admin" ? "Administrador" : "Usuário"}</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={logout}
          className="w-full justify-start gap-2 text-white/40 hover:text-red-400 hover:bg-red-500/10 text-xs"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sair do sistema
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen mesh-bg flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col flex-shrink-0"
        style={{ background: "rgba(10,10,26,0.8)", backdropFilter: "blur(20px)", borderRight: "1px solid rgba(255,255,255,0.05)" }}>
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-64 flex flex-col"
            style={{ background: "rgba(10,10,26,0.98)", backdropFilter: "blur(20px)", borderRight: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="flex justify-end p-4">
              <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)} className="text-white/50 hover:text-white">
                <X className="w-5 h-5" />
              </Button>
            </div>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <header className="lg:hidden flex items-center gap-4 px-4 py-3 border-b border-white/5"
          style={{ background: "rgba(10,10,26,0.8)", backdropFilter: "blur(20px)" }}>
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)} className="text-white/60 hover:text-white">
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)" }}>
              <Headphones className="w-4 h-4 text-white" />
            </div>
            <span className="font-black text-white text-sm">HeadsetControl</span>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
