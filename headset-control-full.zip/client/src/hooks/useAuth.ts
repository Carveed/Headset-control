import { useAuth as useCoreAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export function useAuth() {
  const core = useCoreAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.setData(undefined, null);
      utils.auth.me.invalidate();
      navigate("/login");
    },
  });

  return {
    user: core.user,
    loading: core.loading,
    isAuthenticated: core.isAuthenticated,
    isAdmin: core.user?.role === "admin",
    logout: () => logoutMutation.mutate(),
  };
}
